declare module 'formatic'
