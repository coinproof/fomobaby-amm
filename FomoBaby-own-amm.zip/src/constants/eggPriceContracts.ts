const priceContracts: {cakeAddress: string, busdAddress: string, lpAddress:string} = {
  cakeAddress: '0x82D6E409438E9c2eAEd8ceec4Bd95918cbd17c87',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0xF05437D8CDab26596bFF8a59D94919A9409b2A25'
}

export default priceContracts